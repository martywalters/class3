# test_driver.py
#Intermediate Python Programming - Lab2 Sean Walters
from Helpers import *

print(inputInt("Please enter a number: ", 0, 100))
print(inputFloat("Please enter a number: ", -10, 1000))
print(inputString("Enter some text: ", 5, 10))
print(inputDate("Enter a date: "))
